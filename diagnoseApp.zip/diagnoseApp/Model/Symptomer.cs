﻿namespace diagnoseApp.Model
{
    public class Symptomer
    {
        public int id { get; set; }
        public string feber { get; set; }
        public string hoste { get; set; }
        public string hodepine { get; set; }
        public string slapphet { get; set; }
        public string tungpusthet { get; set; }
        public string lukt { get; set; }
        public string smak { get; set; }
        public string oppkast { get; set; }
        public string diare { get; set; }




    }
}

